package com.example.taskcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskCrudApplication.class, args);
	}

}
